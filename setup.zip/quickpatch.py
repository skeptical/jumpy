import sys, os

# usage: quickpatch diff src

def contains(_list, sublist):
	return set(sublist).issubset(_list)

diff = open(sys.argv[1],'r').readlines()
src = open(sys.argv[2],'r').readlines()

for i in range(len(src)):
	src[i] = src[i].rstrip()
for i in range(len(diff)):
	diff[i] = diff[i].rstrip()

index = -1
valid = False
additions = 0
deletions = 0

for i in range(len(diff)):
	line = diff[i]
#	print line
	if line == '' or line[0:4] == '+++ ' or line[0:4] == '--- ':
		continue
	elif line[0] == '&':
		# '&' means append everything after this as raw text
		if not contains(src, diff[i+1:]):
			src.extend(diff[i+1:])
			additions += (len(diff)-i-1)
		break
	elif line[0] == '@':
		# reset for each hunk
		index = -1
		valid = False
	elif line[0] == ' ':
		# reset for each chunk
		index = -1
		valid = False
		# try to find the line
		if line:
			try: index = src.index(line[1:])
			except ValueError: continue
			valid = True
			index +=1
	elif line[0] == '-' and line[1:].strip():
		# try to find the line
		try: index = src.index(line[1:])
		except ValueError: continue
		valid = True
		src[index] = None
		deletions += 1
	elif line[0] == '+':
		if not valid: continue
		if index == -1:
			src.append(line[1:])
			additions += 1
		else:
			if src[index] != line[1:]:
				src.insert(index, line[1:])
				additions += 1
			index +=1

if additions + deletions > 0:
	print "backing up and patching %s: %d additions, %d deletions" % (os.path.basename(sys.argv[2]), additions, deletions)
	bak = "%s.bak" % sys.argv[2]
	if os.path.exists(bak): os.remove(bak)
	os.rename(sys.argv[2], bak)
	dest = open(sys.argv[2], 'wb')
	for line in src:
		if line is not None: dest.write(line+'\r\n')
else:	
	print "%s: unchanged." % (os.path.basename(sys.argv[2]))

