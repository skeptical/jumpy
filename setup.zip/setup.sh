#!/bin/bash

# -----------------------------------------------
# functions
# -----------------------------------------------

# ansi colors
black=$'\e[30m'
red=$'\e[31m'
green=$'\e[32m'
yellow=$'\e[33m'
blue=$'\e[34m'
magenta=$'\e[35m'
cyan=$'\e[36m'
white=$'\e[37m'
gray=$'\e[1;30m'
ltred=$'\e[1;31m'
ltgreen=$'\e[1;32m'
ltyellow=$'\e[1;33m'
ltblue=$'\e[1;34m'
ltmagenta=$'\e[1;35m'
ltcyan=$'\e[1;36m'
ltwhite=$'\e[1;37m'
reset=$'\e[0m'

log () {
	echo -e "$@" | tee -a "$log"
}

ok () {
	echo -e "$@" >> "$log"
	echo -e "${ltyellow}+ ${ltgreen}${@}${reset}"
#	echo -e "${ltyellow}\xe2\x9c\x94 ${ltgreen}${@}${reset}"
}

warn () {
	echo -e "Warning : $@" >> "$log"
	echo -e "${ltyellow}Warning : ${@}${reset}"
}

err () {
	echo -e "Error : $@" >> "$log"
	echo -e "\n${ltred}Error : ${@}${reset}\n\n"
	[ "$pause" = "yes" ] && pause "Press any key to exit..."
	exit -1
}

prompt () {
	echo -e "$@" >> "$log"
	echo -e "${ltcyan}${@}${reset}"
}

pause () {
	if [ "$1" = "" ] ; then prompt="Press any key to continue..." ; else prompt="$@" ; fi
	printf "${ltcyan}$prompt${reset}"
	read -n 1
	printf "\r                                                       \r"
}

trim () {
	echo "$@"
}

clearsetting () {
	mv -f "$PMS_conf_new" "$PMS_conf_tmp"
	grep -v $1 "$PMS_conf_tmp" 2>/dev/null 1>"$PMS_conf_new"
}

getsetting () {
	name=${1//\./_dot_}
	name=${name//-/_dash_}
	raw=$(grep $1 "$PMS_conf_new" 2>/dev/null)
	if [ $? = 0 ] ; then
		val=$(trim ${raw##*=})
	else
		val=$2
	fi
	eval "$name=\$val"
}

setsetting () {
	clearsetting $1
	echo "$1 = $2" >> "$PMS_conf_new"
	log "setting $1 = $2"
	changed=yes
}

save () {
	log backing up and replacing ${PMS}.conf
	mv -f "$PMS_conf" "$PMS_conf.bak" 1>>"$log" 2>&1
	mv -f "$PMS_conf_new" "$PMS_conf" 1>>"$log" 2>&1
}

easy_install_module () {
	if [ "$easy_install" = "" ] ; then
		log checking setuptools
		if [ -e "$PYTHONDIR/bin/easy_install" ]; then
			easy_install=$PYTHONDIR/bin/easy_install
		else
			easy_install=easy_install
		fi
		"$easy_install" &>/dev/null
		if [ $? != 0 ] ; then
			$easy_install --user --version 1>>"$log" 2>&1
			if [ $? = 0 ] ; then
				easy_install="$easy_install --user"
				log setuptools are installed
			else
				easy_install="sudo $easy_install"
				warn "setuptools doesn't support --user"
			fi
		else
			err setuptools not found
		fi
	fi
	log installing $1
	echo -e "\ntrying '$easy_install -U $1'" 1>>"$log" 2>&1
	[[ "$easy_install" == *sudo* ]] && [ "$(id -u)" != "0" ] && prompt need admin rights to install $1
	$easy_install -U $1 1>>"$log" 2>&1
#	$install $1 2>&1 | tee -a "$log"
	return ${PIPESTATUS[0]}
}

install_module () {
	attempted=
	while : ; do
		if [ "$2" = "" ] ; then mod=$1; else mod=$2; fi
		log checking $1
		"$python_dot_path" -c "import $mod" 1>>"$log" 2>&1
		if [ $? != 0 ] ; then
			if [ "$attempted" != "yes" ] ; then
				attempted=yes
				easy_install_module $1
				return $?
			else
				err unable to install $1
			fi
		else
			ok $1 is installed
			break
		fi
	done
	attempted=
}

download () {
	fname=$(basename $1)
	tmpname=$fname.part
	log downloading "$1"
	touch "$PWD/$tmpname"
	chmod 777 "$PWD/$tmpname"
	curl -k -L -# -o "$tmpname" -f "$1"
	[ $? != 0 ] && echo download error>>"$log"
	mv -f "$tmpname" "$fname" 1>>"$log" 2>&1
}

getdist () {
	# mostly condensed from http://www.unix.com/302211858-post6.html
	while : ; do
		dist=$(uname -s 2>/dev/null)
		if [ "$dist" = "Linux" ] ; then
			[ -r /etc/lsb-release ] && dist=$(grep 'DISTRIB_ID' /etc/lsb-release | sed 's/DISTRIB_ID=//' | head -1)
			[ -n "$dist" ] && break
			dist=$(find /etc/ -maxdepth 1 -name '*release' 2> /dev/null | sed 's/\/etc\///' | sed 's/-release//' | head -1)
			[ -n "$dist" ] && break
			dist=$(find /etc/ -maxdepth 1 -name '*version' 2> /dev/null | sed 's/\/etc\///' | sed 's/-version//' | head -1)
			[ -n "$dist" ] && break
		fi
		[ -n "$dist" ] && break
		[ -e /proc/version ] && dist="unsure $(cat /proc/version)" && break
		[ -e /etc/issue ] && dist="unsure $(cat /etc/issue)" && break
		dist=unknown
		break
	done
	dist="$(tr [A-Z] [a-z] <<< "$dist")"
	echo dist=$dist >> "$log"
}

# see http://distrowatch.com/dwres.php?resource=package-management

dist_pkg_install () {
	[ ! -n "$dist" ] && getdist
	if [ ! -n "$install" ] ; then
		if   [[ "$dist" == *ubuntu* ]] || [[ "$dist" == *debian* ]] || \
			  [[ "$dist" == *mint* ]] || [[ "$dist" == *knoppix* ]] || \
			  [[ "$dist" == *aptosid* ]] ; then
			install="sudo apt-get -q=2 -y install"
		## untested ##
		elif [[ "$dist" == *fedora* ]] || [[ "$dist" == *centos* ]] || \
			  [[ "$dist" == *redhat* ]] || [[ "$dist" == *scientific* ]] ; then
			install="sudo yum install"
		elif [[ "$dist" == *gentoo* ]] ; then
			install="sudo emerge --autounmask"
		elif [[ "$dist" == *suse* ]] ; then
			install="sudo zypper in"
		elif [[ "$dist" == *mageia* ]] || [[ "$dist" == *mandriva* ]] ; then
			install="urpmi"
		elif [[ "$dist" == *slack* ]] ; then
			install="slackpkg install"
		elif [[ "$dist" == *vector* ]] ; then
			install="slapt-get --install"
		elif [[ "$dist" == *zenwalk* ]] ; then
			install="netpkg"
		elif [[ "$dist" == *foresight* ]] || [[ "$dist" == *rpath* ]]  ; then
			install="sudo conary update"
		elif [[ "$dist" == *arch* ]] ; then
			install="pacman -Sy"
		elif [[ "$dist" == *sabayon* ]] ; then
			install="equo install"
		elif [[ "$dist" == *pardus* ]] ; then
			install="pisi install"
		elif [[ "$dist" == *lunar* ]] ; then
			install="lin"
		elif [[ "$dist" == *mage* ]] ; then
			install="cast"
		elif [[ "$dist" == *freebsd* ]] ; then
			install="pkg_add -r"
		else
			install="unknown"
		fi
	fi
	if [ "$install" != "unknown" ] ; then
		echo running $install $1 >> "$log"
		[[ "$install" == *sudo* ]] && [ "$(id -u)" != "0" ] && prompt need admin rights to install $1
		$install $1 2>&1 | tee -a "$log"
		return ${PIPESTATUS[0]}
	fi
	return 1
}

reset () {
	export context=
	export pluginsdir=
	export xterm=
	export log=
	export pause=
	export SELFUPDATE=
	export UMSINSTALLER=
	export RESTARTDIR=
	export RESTART=
}

restart () {
	cd "$RESTARTDIR" 1>>"$log" 2>&1
#	echo -e "starting: ${RESTART}\nin directory: $PWD" 1>>"$log" 2>&1
#	echo "restarting ${PMS}..."
	_restart="$RESTART"
	reset
	$_restart &
}

finish () {
	_pause=$pause
	[ "$RESTART" != "" ] && [ "$UMSINSTALLER" != "yes" ] && restart
	[ "$_pause" = "yes" ] && pause Press any key to exit...
	exit 0
}

getPMSname () {
	if [ "$1" != "" ] ; then
		PMS=$(basename "$1")
		PMS=${PMS%.*}
	else
		if [ -e "$PMSDIR/pms*.jar" ] ; then PMS="PMS" ; else PMS="UMS" ; fi
	fi
}

getinstallername () {
	iname=$(ps -Ao command | grep jumpy-\.*run | grep -v grep | sed -E 's/.+(jumpy-[^ ]+?).*/\1/')
}

realpath () {
	local path
	path=$(readlink -f "$1" 2>/dev/null)
	[ $? != 0 ] && path=$(python -c "import os,sys;print os.path.realpath(\"$1\")")
	echo $path
}

cleanup () {
	if [ "$1" = "all" ] && [ "$remove" != "" ] ; then
		echo "removing $remove" >> "$log"
		rm -fr $remove 1>>"$log" 2>&1
	else
		remove="$remove $@"
	fi
}

appexists () {
	lsregister=/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister
	# rebuild LaunchServices db:
	$lsregister -kill -r -domain local -domain system -domain user
	$lsregister -dump | grep $1
}

loginit () {
	log=$(realpath setup.log)
	touch "$log"
	if [ $? != 0 ] && [ "$PMS_conf" != "" ] ; then
		log=$(dirname "$PMS_conf")\setup.log
		touch "$log"
	fi
	[ ! -e "$log" ] && log=/dev/null
	export log
	date > "$log"
}

# -----------------------------------------------
# init
# -----------------------------------------------

if [ "$context" = "" ] ; then
#	reset

	# osx or linux?
	if [ "$(uname -s)" = "Darwin" ] ; then os=osx; else os=linux; fi
	export os
	
	loginit
	
	[ ! -e "$TMPDIR" ] && TMPDIR=/tmp/
	# is context installer or script?
	if [[ "${PWD}" == *"${TMPDIR}"* ]] ; then
		export context=installer
		# our parent process' PWD is either pluginsdir
		ppid=$(ps -fp $PPID | awk 'NR==2{print $3}')
		pluginsdir=$(lsof -a -p $ppid -d cwd -Fn | grep ^n)
		pluginsdir=${pluginsdir:1}
		# or its parent directory if we're running via UMS installer
		[ "$PROFILE_PATH" != "" ] && pluginsdir=$pluginsdir/plugins
		export pluginsdir
		setupdir=$(realpath "$PWD/jumpy/setup")
	else
		export context=script
		export pluginsdir=$(realpath "$PWD/../..")
		setupdir=$(realpath "$PWD")
#		if [ "$UPDATE" != "" ] ; then
#			cd "$pluginsdir"
#			download $UPDATE
#			export context=installer
#			./$(basename $UPDATE)
#			exit $?
#		fi
	fi

	# try to update to latest setup before proceeding
#	homeurl=http://127.0.0.1:8000
	homeurl=http://skeptical.github.io/jumpy
	download $homeurl/setup.zip
	[ $? = 0 ] && unzip -o setup.zip -d "$setupdir" -x setup.bat bin/* 1>>"$log" 2>&1
	[ $? = 0 ] && relaunch=yes
	chmod 777 "$0"
	rm -vf "$PWD/setup.zip" 1>>"$log" 2>&1

	PMSDIR=$(dirname "$pluginsdir")
	getPMSname "$PROFILE_PATH"
	export PMS
	export PMSDIR
	export SELFUPDATE=
	[ "$1" = "--selfupdate" ] && export SELFUPDATE=yes
	[ "$PROFILE_PATH" != "" ] && [ "$PMS" = "UMS" ] && [ "$SELFUPDATE" != "yes" ] && export UMSINSTALLER=yes
	
	# relaunch inside a console if not already in one
	if ! tty -s ; then
		export xterm=yes
		export pause=yes
		# open -a Terminal.app "$0"
		if [ "$os" = "osx" ] ; then _xterm=/usr/X11/bin/xterm; else _xterm=xterm; fi
		$_xterm -title "Jumpy Setup" -fa "Monospace" -fs 11 -fg white -bg black -sb -rightbar -e $0 $@
		pause=
		finish
	fi
	# relaunch if using newer setup
	if [ "$relaunch" = "yes" ] ; then
		log "relaunching..."
		log
		$0 $@
#		finish
		exit 0
	fi
fi

# -----------------------------------------------
# ready
# -----------------------------------------------

ver=2.3

if [ "$UMSINSTALLER" = "yes" ] && [ "$UMS_VERSION" = "" ] ; then
	getinstallername	
	err "this installer requires UMS 2.0.1 or higher for automatic install.\n\nPlease shut down UMS and run the downloaded installer\n    ${iname}\nmanually in your plugins folder."
fi

#echo RESTART=$RESTART
#echo SELFUPDATE=$SELFUPDATE
#echo UMSINSTALLER=$UMSINSTALLER

# -----------------------------------------------
# smoke tests
# -----------------------------------------------

# 32 bit or 64?
uname -m | grep 64 &>/dev/null
[ $? = 0 ] && bits=64

# do we have permissions?
test="$pluginsdir/test.txt"
touch "$test"
chmod 777 "$test"
if [ $? = 0 ] ; then
	[ ! -x "$test" ] && forbid="execute"
	[ ! -w "$test" ] && forbid="write $forbid"
	[ ! -r "$test" ] && forbid="read $forbid"
	rm "$test"
else
	forbid="read write execute"
fi

if [ "$forbid" != "" ] ; then
	err "No permission to $forbid in '$pluginsdir'"
else
	ok permissions are ok
fi

# check our location

# find debug.log
if [ -e "$PMSDIR/debug.log" ] ; then
	DEBUG_LOG="$PMSDIR/debug.log"
elif [ "$PROFILE_PATH" != "" ] ; then
	DEBUG_LOG="$(dirname \"$PROFILE_PATH\")/debug.log"
else
	if [ "$os" = "osx" ] ; then
		DEBUG_LOG="$HOME/Library/Application Support/$PMS/debug.log"
	else
		DEBUG_LOG="$HOME/.config/$PMS/debug.log"
	fi
fi
if [ ! -e "$DEBUG_LOG" ] ; then
	if [ "$context" = "script" ] ; then
		err "can't find debug.log.\n\nPlease verify that this script is located inside\n'plugins/jumpy/setup' in your ${PMS} Program folder.\n"
	else
		err "can't find debug.log.\n\nPlease verify that this installer is located in your ${PMS} 'plugins' folder.\n"
	fi
fi

# find PMS_conf
if [ "$PROFILE_PATH" != "" ] ; then
	PMS_conf="$PROFILE_PATH"
else
	PMS_conf=$(cat "$DEBUG_LOG" | grep " Profile path: ")
	PMS_conf="${PMS_conf##*path: }"
fi
if [ ! -e "$PMS_conf" ] ; then err "can't find ${PMS}_conf.\n\nPlease start up ${PMS} and shut it down again to ensure that debug.log is valid." ; fi
getPMSname "$PMS_conf"

## are we root?
#if [ "$(id -u)" = "0" ] ; then root=yes; fi

## is PMS running?
#lsof 2>/dev/null | grep "$PMSDIR/debug.log" 2>/dev/null | grep java 1>/dev/null 2>&1
#if [ "$?" = "0" ] ; then
#	echo debug.log is open in java.
#	err please shut down ${PMS} before running this $context.
#fi

# double-check logging
[ "$log" = "/dev/null" ] && loginit

if [ "$SELFUPDATE" = "yes" ] ; then mode="self-update"
elif [ "$UMSINSTALLER" = "yes" ] ; then mode="ums installer"
else mode=$context
fi
echo -e "\njumpy setup $ver - mode: $mode\n" >> "$log"

uname -a >> "$log"
[ "$os" = "linux" ] && getdist
echo -e "PMSDIR=$PMSDIR\n" >> "$log"

# get server ip
if [ "$server_ip" = "" ] ; then
	server_ip=$(cat "$PMSDIR/debug.log" | grep " Using address /")
	server_ip="${server_ip##*address /}"
	server_ip="${server_ip%% *}"
fi
echo "server_ip=$server_ip" >> "$log"

# -----------------------------------------------
# jumpy
# -----------------------------------------------

if [ "$context" = "installer" ] ; then
	jumpyjar=$(find *jumpy*.jar)
	cp -fr * "$pluginsdir" 1>>"$log" 2>&1
	log="$pluginsdir/jumpy/setup/setup.log"
	mv "$pluginsdir/setup.log" "$log"
	cd "$pluginsdir"
#	[ "$PMS" != "UMS" ] && for i in *jumpy*.jar; do
	for i in *jumpy*.jar; do
		if [ "$i" != "$jumpyjar" ] ; then
			log renaming $i
			mv $i $i.bak 1>>"$log" 2>&1
			[ $? != 0 ] && err unable to rename $i
		fi
	done
	[ -e "$jumpyjar" ] && ok $jumpyjar is installed
	cd "$pluginsdir/jumpy/setup"
fi

# -----------------------------------------------
# settings
# -----------------------------------------------

echo -e "\nfiles:" >>"$log"
find . >>"$log"
echo "" >>"$log"

log found ${PMS}.conf: $PMS_conf
PMS_conf_new=${PMS_conf}.new
PMS_conf_tmp=${PMS_conf}.tmp
cp -f "$PMS_conf" "$PMS_conf_new" 1>>"$log" 2>&1
getsetting python.path python
getsetting rtmpdump.path rtmpdump
getsetting xbmc.path
getsetting xbmc.main.path xbmc
getsetting bin.path
getsetting youtube-dl.lib.path

if [ "$bin_dot_path" != "" ] ; then bin_dot_path=${bin_dot_path//,/:}; fi
bindir="$PMSDIR/$os"
extrapath="$bindir:$bin_dot_path"
echo search path=$extrapath >>"$log"
export PATH=$extrapath:$PATH
echo "" >>"$log"

# -----------------------------------------------
# python
# -----------------------------------------------

log checking python
"$python_dot_path" --version 2>&1 | tee -a "$log"
if [ ${PIPESTATUS[0]} != 0 ] ; then
	err "python not found.\nPlease install python 2.7 and rerun this $context."
else
	setsetting python.path "$python_dot_path"
	ok python is installed
fi
PYTHONDIR=$("$python_dot_path" -c "import sys;print sys.prefix")
echo "" >>"$log"

# -----------------------------------------------
# py4j
# -----------------------------------------------

install_module py4j
attempted=

while : ; do
	log checking py4j version
	PY4J=$(python -c "import py4j.version;print py4j.version.__version__" 2>>"$log")
	log $PY4J
	if [ "$attempted" != "yes" ] && [ "$PY4J" != "0.8" ] ; then
		[ "$PY4J" != "0.8" ] && easy_install_module py4j
		attempted=yes
	else
		if [ "$PY4J" != "0.8" ] ; then
			warn py4j is not version 0.8
		else
			[ -d "$pluginsdir/jumpy/lib/py4j" ] && cleanup "$pluginsdir/jumpy/lib/py4j"
		fi
		break
	fi
done
echo "" >>"$log"
cd "$pluginsdir/jumpy/setup"

# -----------------------------------------------
# beautifulsoup4
# -----------------------------------------------

install_module beautifulsoup4 bs4
echo "" >>"$log"
cd "$pluginsdir/jumpy/setup"

attempted=
while : ; do
	log checking lxml
	"$python_dot_path" -c "import lxml" 1>>"$log" 2>&1
	if [ $? != 0 ] ; then
		if [ "$attempted" != "yes" ] ; then
			log installing lxml
			attempted=yes
			if [ "$os" = "osx" ] ; then
				pyver=$("$python_dot_path" -c 'import sys;print "%s.%s"%(sys.version_info.major,sys.version_info.minor)')
				prompt need admin rights to install lxml
				sudo STATIC_DEPS=true /usr/bin/easy_install-$pyver lxml
			else 
				dist_pkg_install python-lxml
			fi
		else
			failed=yes
			warn "unable to install lxml"
			break
		fi
	else
		ok lxml is installed
		break
	fi
done
echo "" >>"$log"
cd "$pluginsdir/jumpy/setup"

# -----------------------------------------------
# xbmc
# -----------------------------------------------

attempted=
while : ; do
	log checking xbmc
	if [ "$os" = "osx" ] ; then
		printf "please wait...\r"
		appexists com.teamxbmc.xbmc 1>>"$log" 2>&1
	else
		xbmc=xbmc
		[ -e "$xbmc_dot_main_dot_path/xbmc" ] && xbmc=$xbmc_dot_main_dot_path/xbmc
		"$xbmc" --version 2>>"$log" | tee -a "$log"
	fi
	if [ ${PIPESTATUS[0]} != 0 ] ; then
		if [ "$attempted" != "yes" ] ; then
			attempted=yes
			if [ "$os" = "osx" ] ; then
				log Installing xbmc
				if [[ `sysctl hw.machine` = "hw.machine: Power Macintosh" ]]; then
					dmg=ppc/xbmc-11.0-ppc.dmg
				else
					[ "$bits" = "64" ] && dmg=xbmc-12.2-x86_64.dmg 
					[ "$bits" = "32" ] && dmg=xbmc-12.2-x86.dmg
				fi
				[ ! -e $dmg ] && download http://mirrors.xbmc.org/releases/osx/$dmg
				[ "$(id -u)" != "0" ] &&  prompt need admin rights to install ${dmg}
				mountpath=$(sudo hdiutil attach $dmg | grep Apple_HFS | awk '{print $3}' | tee -a "$log")
				if [ ${PIPESTATUS[0]} = 0 ] ; then
#					echo "mountpath=$mountpath"
					sudo cp -fR "$mountpath" /Applications 1>>"$log" 2>&1
					sudo hdiutil unmount "$mountpath" 1>>"$log" 2>&1
					cleanup $dmg
				else
					prompt please install plugins/jumpy/setup/$dmg with Finder
				fi
			elif ! dist_pkg_install xbmc ; then
				prompt "sorry, unable to install xbmc for your distro\nplease follow the 'Linux' link on the xbmc downloads page for instructions"
#				xdg-open http://wiki.xbmc.org/index.php?title=Installing_XBMC_for_Linux
#				pause
				failed=yes
				break
			fi
		else
			warn problem installing xbmc - see "$log"
			failed=yes
			break
		fi
	else
		ok xbmc is installed
		break
	fi
done
echo "" >>"$log"
cd "$pluginsdir/jumpy/setup"

# -----------------------------------------------
# jumpy xbmc repo
# -----------------------------------------------

attempted=
while : ; do
	log adding jumpy repo
	if [ ! -e "$xbmc_dot_path" ] ; then
		if [ "$os" = "osx" ] ; then
			xbmc_dot_path="$HOME/Library/Application Support/XBMC"
		else
			xbmc_dot_path="$HOME/.xbmc"
		fi
	fi
	addondir="$xbmc_dot_path/addons"
	[ ! -e "$addondir" ] && mkdir -p "$addondir"
	[ -e "$addondir" ] && unzip -o script.module.jumpy-2.0.0.zip -d "$addondir" 1>>"$log" 2>&1
	[ -e "$addondir" ] && unzip -o repository.jumpy.addons-1.0.0.zip -d "$addondir" 1>>"$log" 2>&1
	break
done
echo "" >>"$log"
cd "$pluginsdir/jumpy/setup"

# -----------------------------------------------
# rtmpdump
# -----------------------------------------------

attempted=
while : ; do
	log checking rtmpdump
	"$rtmpdump_dot_path" --help 2>&1 | grep "RTMPDump" 2>>"$log" | tee -a "$log"
	if [ ${PIPESTATUS[0]} != 0 ] ; then
		if [ "$attempted" != "yes" ] ; then
			# if we have gcc/ssl/pthreads/libz we can try to build rtmpdump
			for i in openssl polarssl ; do
				echo -e "#include <$i/ssl.h>\n#include <pthread.h>\n#include <zlib.h>\nvoid main(int a,char**v){}" | gcc -xc - -o /dev/null 2>>"$log"
				[ $? != 0 ] && continue
				ssl=$i && break
			done
			if [ "$ssl" != "" ] ; then
				log compiling from source...
#				curl -k -L -# -o rtmpdump.tar.gz -f https://github.com/svnpenn/rtmpdump/tarball/svnpenn &>/dev/null
				curl -k -L -# -o rtmpdump.tar.gz -f https://github.com/svnpenn/rtmpdump/archive/master.tar.gz &>/dev/null
				if [ $? = 0 ] ; then
#					srcdir=$(tar --exclude="*/*" -tf rtmpdump.tar.gz)
					srcdir=$(tar tf rtmpdump.tar.gz | sed -e 's@/.*@@' | uniq)
					tar -zxf rtmpdump.tar.gz 1>>"$log" 2>&1
					cd $srcdir 1>>"$log" 2>&1
					if [ "$os" = "osx" ] ; then SYS=darwin; else SYS=posix; fi
					if [ "$ssl" = "openssl" ] ; then CRYPTO=OPENSSL; else CRYPTO=POLARSSL; fi
					make SYS=$SYS CRYPTO=$CRYPTO SHARED= 1>>"$log" 2>&1
#					# for a full custom install remove the hard-coded prefix from Makefile:
#					grep -v prefix= Makefile > Makefile.new
#					make -f Makefile.new prefix=$PWD/../rtmpdump SYS=$SYS CRYPTO=$CRYPTO SHARED= install 1>>"$log" 2>&1
					if [ $? = 0 ] ; then
						log Installing to "$bindir"
						[ ! -e "$bindir" ] && mkdir "$bindir"
						mv -f rtmpdump "$bindir/" 1>>"$log" 2>&1
						rtmpdump_dot_path="$bindir/rtmpdump"
						attempted=ok
					else
						log error building rtmpdump
					fi
					cd ..
					cleanup $srcdir rtmpdump.tar.gz
				else
					log error downloading source code
				fi
			fi
			cd "$pluginsdir/jumpy/setup"
			if [ "$attempted" != "ok" ] ; then
				if [ "$os" = "osx" ] && [ "$(uname -r)" \> "11" ] ; then
					# OS X 10.7 (Lion)+
					pkg=rtmpdump-2.4_mac_os
					[ ! -e $pkg.zip ] && download http://trick77.com/wp-content/uploads/2008/01/$pkg.zip
					[ ! -e $pkg.pkg ] &&  unzip -o $pkg 1>>"$log" 2>&1
					[ "$(id -u)" != "0" ] &&  prompt need admin rights to install $pkg.pkg
					[ -e $pkg.pkg ] &&  sudo installer -pkg "$PWD/$pkg.pkg" -target /
					cleanup $pkg.zip $pkg.pkg
				elif ! dist_pkg_install rtmpdump ; then
					prompt "sorry, unable to install rtmpdump for your distro"
					failed=yes
					break
				fi
			fi
			attempted=yes
		else
			warn problem installing rtmpdump - see "$log"
			failed=yes
			break
		fi
	else
		setsetting rtmpdump.path "$rtmpdump_dot_path"
		ok rtmpdump is installed
		break
	fi
done
echo "" >>"$log"
cd "$pluginsdir/jumpy/setup"

# -----------------------------------------------
# phantomjs
# -----------------------------------------------

attempted=
while : ; do
	log checking phantomjs
	phantomjs --version 2>>"$log" | tee -a "$log"
	if [ ${PIPESTATUS[0]} != 0 ] ; then
		if [ "$attempted" != "yes" ] ; then
			log Installing phantomjs
			attempted=yes
			if [ "$os" = "osx" ] ; then
				pkg=phantomjs-1.9.2-macosx
				[ ! -e $pkg.zip ] && download https://phantomjs.googlecode.com/files/$pkg.zip
				[ ! -e $pkg/bin/phantomjs ] &&  unzip -o $pkg.zip $pkg/bin/phantomjs 1>>"$log" 2>&1
				cleanup $pkg.zip
			else
				if [ "$bits" = "64" ] ; then
					pkg=phantomjs-1.9.2-linux-x86_64
				else
					pkg=phantomjs-1.9.2-linux-i686
				fi
				[ ! -e $pkg.tar.bz2 ] && download https://phantomjs.googlecode.com/files/$pkg.tar.bz2
				[ ! -e $pkg/bin/phantomjs ] && tar -jxvf $pkg.tar.bz2 $pkg/bin/phantomjs 1>>"$log" 2>&1
				cleanup $pkg.tar.bz2
			fi
			log Installing to "$bindir"
			[ ! -e "$bindir" ] && mkdir "$bindir"
			mv -f "$pkg/bin/phantomjs" "$bindir/" 1>>"$log" 2>&1
			cleanup $pkg
		else
			warn problem installing phantomjs - see "$log"
			failed=yes
			break
		fi
	else
		ok phantomjs is installed
		break
	fi
done
echo "" >>"$log"
cd "$pluginsdir/jumpy/setup"

# -----------------------------------------------
# youtube-dl
# -----------------------------------------------

attempted=
while : ; do
	log checking youtube-dl

checkver=\
"import os,sys,urllib2;"\
"VERSION_URL = 'http://rg3.github.io/youtube-dl/update/LATEST_VERSION';"\
"newversion = urllib2.urlopen(VERSION_URL).read().decode('utf-8').strip();"\
"print newversion;sys.stdout.flush();"\
"os.chdir(sys.argv[1]) if os.path.exists(sys.argv[1]) else sys.exit(0);"\
"from version import __version__;"\
"print 'OK',__version__ if newversion == __version__ else '';"
	
	newver=$(python -c "$checkver" "$youtube_dash_dl_dot_lib_dot_path" 2>>"$log" | tee -a "$log")
#	echo $newver
	if [[ "$newver" != *OK* ]] ; then
		if [ "$attempted" != "yes" ] ; then
#			log Installing youtube-dl $newver
			attempted=yes
			pkg=youtube-dl-$newver.tar.gz
			[ ! -e $pkg ] && download http://youtube-dl.org/downloads/$newver/$pkg
			[ -e $pkg ] && tar -zxf $pkg 1>>"$log" 2>&1
			log Installing to "$bindir"
			[ ! -e "$bindir" ] && mkdir "$bindir"
			[ -e "$bindir/youtube_dl" ] && rm -fr "$bindir/youtube_dl"
			mv -f "youtube-dl/youtube_dl" "$bindir/" 1>>"$log" 2>&1
			youtube_dash_dl_dot_lib_dot_path=$bindir/youtube_dl
			cleanup $pkg youtube-dl
		else
			warn problem installing youtube-dl - see "$log"
			failed=yes
			break
		fi
	else
		echo ${newver/OK /}
		setsetting "youtube-dl.lib.path" "$youtube_dash_dl_dot_lib_dot_path"
		ok youtube-dl is installed
		break
	fi
done
echo "" >>"$log"
cd "$pluginsdir/jumpy/setup"

# -----------------------------------------------
# imagemagick
# -----------------------------------------------

attempted=
while : ; do
	log checking imagemagick convert
	convert --version 2>>"$log" | grep Version | tee -a "$log"
	if [ ${PIPESTATUS[0]} != 0 ] ; then
		if [ "$attempted" != "yes" ] ; then
			log Installing imagemagick
			attempted=yes
			if [ "$os" = "osx" ] ; then
				kernel=$(uname -r)
				if [ "$kernel" \> "11" ] && [ "$(uname -m)" = "x86_64" ] ; then
					if [ "$kernel" \< "12" ] ; then
						# OS X 10.7 (Lion)
						pkg=ImageMagick-x86_64-apple-darwin11.4.0.tar.gz
						url=http://www.civproject.net/Archive/Tools/MacOS%20X/$pkg
					else
						# OS X 10.8 (Mountain Lion)
						pkg=ImageMagick-x86_64-apple-darwin13.0.0.tar.gz
						url=http://www.imagemagick.org/download/binaries/$pkg
					fi
					[ ! -e $pkg ] && download $url
					srcdir=$(tar tf $pkg | sed -e 's@/.*@@' | uniq)
					tar -zxf $pkg 1>>"$log" 2>&1
					log Installing to "$bindir"
					[ ! -e "$bindir" ] && mkdir "$bindir"
					[ -e "$bindir/$srcdir" ] && rm -fr "$bindir/$srcdir" 1>>"$log" 2>&1
					mv -f "$srcdir" "$bindir/" 1>>"$log" 2>&1
					cat << EOF > "$bindir/convert"
#!/bin/sh
export MAGICK_HOME="$bindir/$srcdir"
export PATH="\$MAGICK_HOME/bin:\$PATH"
export DYLD_LIBRARY_PATH="\$MAGICK_HOME/lib/"
convert \$@
EOF
					chmod 755 "$bindir/convert"
					cleanup "$pkg" "$srcdir" 
				else
					prompt "sorry, no imagemagick binary available.\ntry installing 'ImageMagick' with MacPorts or 'imagemagick' with brew."
					failed=yes
					break
				fi
			elif ! dist_pkg_install imagemagick ; then
				prompt "sorry, unable to install imagemagick for your distro"
				failed=yes
				break
			fi
		else
			warn problem installing imagemagick - see "$log"
			failed=yes
			break
		fi
	else
		imconvert="$(which convert)"
		[ "$imconvert" != "$bindir/convert" ] && [ -e "$imconvert" ] && [ ! -e "$bindir/convert" ] && ln -sv "$imconvert" "$bindir/convert" 1>>"$log" 2>&1
		ok imagemagick convert is installed
		break
	fi
done
echo "" >>"$log"
cd "$pluginsdir/jumpy/setup"

# -----------------------------------------------
# temporary move
# -----------------------------------------------
profiledir=$(dirname "$PMS_conf")
confdir=$profiledir/jumpy
[ ! -e "$confdir" ] && mkdir "$confdir"
for f in jumpy.conf jumpy-scripts.ini jumpy-bookmarks.ini economist.csv guardian.csv nyt.csv ; do
	fname=$profiledir/$f
	[ -e "$fname" ] && [ ! -e "$confdir/$f" ] && mv -vf "$fname" "$confdir/" 1>>"$log" 2>&1
done

# -----------------------------------------------
# update jumpy-scripts.ini
# -----------------------------------------------

ini=$confdir/jumpy-scripts.ini
dif=jumpy-scripts.diff
[ -e "$ini" ] && [ -e "$dif" ] && "$python_dot_path" quickpatch.py "$dif" "$ini" | tee -a "$log"

# -----------------------------------------------
# done
# -----------------------------------------------

rm -f "$PMS_conf_tmp" 1>>"$log" 2>&1
[ "$changed" = "yes" ] && save
cleanup all
ok done
[ "$failed" = "yes" ] && log "" && warn "some items were not installed\nsee '$log'\n"
[ "$xterm" != "yes" ] && finish
if [ "$RESTART" != "" ] && [ "$pause" = "yes" ] ; then
	echo -e "starting: ${RESTART}\nin directory: $RESTARTDIR" 1>>"$log" 2>&1
	pause Press any key to restart ${PMS}...
elif [ "$pause" = "yes" ] ; then
	pause Press any key to exit...
fi

